import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-veterinarios',
  templateUrl: './veterinarios.component.html',
  styleUrls: ['./veterinarios.component.css']
})
export class VeterinariosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
