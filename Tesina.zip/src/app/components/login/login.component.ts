import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  mascotas:boolean=false;
  registrarse:boolean = false

  constructor() { }

  ngOnInit(): void {
    this.mascotas = false;
    this.registrarse = false
  }

  cliclLogin(){
    this.mascotas = true
    this.registrarse = false
  }

  clickRegistrarse(){
    this.mascotas = false
    this.registrarse = true 
  }

}
