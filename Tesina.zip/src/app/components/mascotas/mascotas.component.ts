import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mascotas',
  templateUrl: './mascotas.component.html',
  styleUrls: ['./mascotas.component.css']
})
export class MascotasComponent implements OnInit {

  agregarMascota:boolean=false
  agregarNota:boolean = false
  verNotas:boolean = false

  constructor() { 
    console.log("Prueba");
    
  }

  ngOnInit(): void {
    this.agregarMascota = false;
    this.agregarNota = false
    this.verNotas= false
  }

  clickAgregarMascota(){
    this.agregarMascota = true;
    this.agregarNota = false

    this.verNotas= false;
  }

  clickAgregarNota(){
    this.agregarMascota = false
    this.agregarNota = true;
    this.verNotas = false
  } 

  clickVerNotas(){
    this.agregarMascota = false
    this.agregarNota = false;
    this.verNotas = true
  }

  regresar(){
    this.agregarMascota = false;
    this.agregarNota= false;
    this.verNotas = false
  }

}
