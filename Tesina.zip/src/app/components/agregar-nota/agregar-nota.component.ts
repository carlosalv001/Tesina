import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar-nota',
  templateUrl: './agregar-nota.component.html',
  styleUrls: ['./agregar-nota.component.css']
})
export class AgregarNotaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
