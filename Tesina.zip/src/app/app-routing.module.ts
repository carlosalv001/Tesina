import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MascotasComponent } from './components/mascotas/mascotas.component';
import { MenuComponent } from './components/menu/menu.component';
import { InformacionComponent } from './components/informacion/informacion.component';
import { AgregarNotaComponent } from './components/agregar-nota/agregar-nota.component';
import { VeterinariosComponent } from './components/veterinarios/veterinarios.component';


const routes: Routes = [
  {path:"login", component:LoginComponent},
  {path:"mascotas", component:MascotasComponent},
  {path:"menu", component:MenuComponent},
  {path:"informacion", component:InformacionComponent},
  {path:"agregar", component:AgregarNotaComponent},
  {path:"veterinarios", component:VeterinariosComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
